﻿{
	"version": 1503982578,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/sprite-sheet0.png",
		"images/peswat-sheet0.png",
		"images/peluru-sheet0.png",
		"images/pesawat-sheet0.png",
		"images/meteor-sheet0.png",
		"images/ledakanmeteor.png",
		"images/ledakanpesawat.png",
		"images/gameover-sheet0.png",
		"images/background-sheet0.png",
		"media/sounddestroy.ogg"
	]
}